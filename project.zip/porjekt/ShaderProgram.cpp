//ShaderProgram.cpp
#include "ShaderProgram.h"
#include <iostream>
#include <glm/gtc/type_ptr.hpp>
#include <vector>

ShaderProgram::ShaderProgram() : programID(0)
{
}

ShaderProgram::~ShaderProgram()
{
    if (programID != 0)
    {
        glDeleteProgram(programID);
    }
}

void ShaderProgram::retrieveUniformLocations()
{
    std::vector<std::string> uniforms = {
        "modelMatrix",
        "viewMatrix",
        "projectionMatrix",
        "materialColor",
        "viewPos",
        "light.position",
        "light.color",
        "light.intensity"};

    for (const auto &name : uniforms)
    {
        GLint location = glGetUniformLocation(programID, name.c_str());
        uniformLocations[name] = location;
    }
}

void ShaderProgram::use()
{
    if (programID == 0)
    {
        std::cerr << "ERROR: Shader program is invalid (programID == 0)." << std::endl;
        return;
    }
    glUseProgram(programID);

    setMat4("viewMatrix", viewMatrix);
    setMat4("projectionMatrix", projectionMatrix);

    setVec3("viewPos", cameraPosition);

    setVec3("light.position", lightPosition);
    setVec3("light.color", lightColor);
    setFloat("light.intensity", lightIntensity);
}

void ShaderProgram::setMat4(const std::string &name, const glm::mat4 &mat)
{
    auto it = uniformLocations.find(name);
    if (it == uniformLocations.end() || it->second == -1)
    {
        return;
    }
    glUniformMatrix4fv(it->second, 1, GL_FALSE, glm::value_ptr(mat));
}

void ShaderProgram::setVec3(const std::string &name, const glm::vec3 &vec)
{
    auto it = uniformLocations.find(name);
    if (it == uniformLocations.end() || it->second == -1)
    {
        return;
    }
    glUniform3fv(it->second, 1, glm::value_ptr(vec));
}

void ShaderProgram::setFloat(const std::string &name, float value)
{
    auto it = uniformLocations.find(name);
    if (it == uniformLocations.end() || it->second == -1)
    {
        return;
    }
    glUniform1f(it->second, value);
}
void ShaderProgram::update(Subject *subject)
{
    Camera *camera = dynamic_cast<Camera *>(subject);
    if (camera)
    {
        viewMatrix = camera->getViewMatrix();
        projectionMatrix = camera->getProjectionMatrix();
        cameraPosition = camera->getPosition();

        use();
        setMat4("viewMatrix", viewMatrix);
        setMat4("projectionMatrix", projectionMatrix);
        setVec3("viewPos", cameraPosition);
    }

    Light *light = dynamic_cast<Light *>(subject);
    if (light)
    {
        lightPosition = light->getPosition();
        lightColor = light->getColor();
        lightIntensity = light->getIntensity();

        use();
        setVec3("light.position", lightPosition);
        setVec3("light.color", lightColor);
        setFloat("light.intensity", lightIntensity);
    }
}

void ShaderProgram::setProgramID(GLuint programID)
{
    this->programID = programID;
    retrieveUniformLocations();
}