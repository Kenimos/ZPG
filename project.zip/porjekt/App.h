// App.h

#ifndef APP_H
#define APP_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <vector>
#include <array>
#include "Camera.h"
#include "Scene.h"
#include "ShaderProgram.h"

class App
{
public:
    App();
    ~App();

    bool init();
    void run();

private:
    GLFWwindow* window;
    Camera camera;
    ShaderProgram* shaderProgram;
    std::vector<Scene*> scenes; 
    int width, height;
    int currentSceneIndex;

    std::array<bool, 10> keyStates;

    // Initialization methods
    bool initGLFW();
    bool initGLEW();

    // Render and update methods
    void processInput();
    void renderScene();

    // Helper methods
    std::string loadShaderSource(const std::string& filePath);

    // Callback functions
    static void framebufferSizeCallback(GLFWwindow* window, int width, int height);
    static void mouseCallback(GLFWwindow* window, double xpos, double ypos);
    static void scrollCallback(GLFWwindow* window, double xoffset, double yoffset);
    void attachShadersToCamera();
};

#endif // APP_H
