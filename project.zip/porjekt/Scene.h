// Scene.h

#ifndef SCENE_H
#define SCENE_H

#include <vector>
#include "DrawableObject.h"
#include "Camera.h"

class Scene
{
public:
    Scene();
    ~Scene();
    Scene(Camera *camera);

    void initShaders();
    void initScene1();
    void initScene2();
    void initScene3();
    void initScene4();
    void draw();

    ShaderProgram *getPhongShader();
    ShaderProgram *getLambertShader();
    ShaderProgram *getBlinnPhongShader();
    ShaderProgram *getConstantShader();

    void setShaderProgram(ShaderProgram *shaderProgram);
    Light *getLight();
    void switchShaders();

private:
    Camera *camera;
    Model *treeModel;
    Model *bushModel;
    Model *sphereModel;
    Model *giftModel;

    void loadModelsScene1();
    void loadModelsScene2();
    void loadModelsScene3();
    void loadModelsScene4();

    std::vector<DrawableObject> drawableObjects;
    Light *light;
    ShaderProgram *shaderProgram;
    ShaderProgram *constantShader;
    ShaderProgram *lambertShader;
    ShaderProgram *phongShader;
    ShaderProgram *blinnPhongShader;
    int currentShaderIndex;
    std::vector<ShaderProgram *> shaders;
};

#endif // SCENE_H
