// Transformation.h

#ifndef TRANSFORMATION_H
#define TRANSFORMATION_H

#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/matrix_transform.hpp>

class Transformation
{
public:
    Transformation();

    void setPosition(const glm::vec3& position);
    void setRotation(float angle, const glm::vec3& axis);
    void setScale(const glm::vec3& scale);

    glm::vec3 getPosition() const;
    glm::quat getRotation() const;
    glm::vec3 getScale() const;

    glm::mat4 getModelMatrix() const;

private:
    glm::vec3 position;
    glm::quat rotation;
    glm::vec3 scale;
};

#endif // TRANSFORMATION_H
