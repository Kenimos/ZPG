
//DrawableObject.cpp
#include "DrawableObject.h"

DrawableObject::DrawableObject(Model *model, ShaderProgram *shaderProgram)
    : model(model), shaderProgram(shaderProgram), color(glm::vec3(1.0f))
{
}

Transformation &DrawableObject::getTransformation()
{
    return transformation;
}

void DrawableObject::setColor(const glm::vec3 &color)
{
    this->color = color;
}

void DrawableObject::setShaderProgram(ShaderProgram *shaderProgram)
{
    this->shaderProgram = shaderProgram;
}

const glm::vec3 &DrawableObject::getColor() const
{
    return color;
}

void DrawableObject::draw()
{

    shaderProgram->use();

    shaderProgram->setMat4("modelMatrix", transformation.getModelMatrix());

    shaderProgram->setVec3("materialColor", color);

    model->draw();
}
