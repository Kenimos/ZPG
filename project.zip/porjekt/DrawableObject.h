// DrawableObject.h

#ifndef DRAWABLEOBJECT_H
#define DRAWABLEOBJECT_H

#include "Model.h"
#include "Transformation.h"
#include "ShaderProgram.h"

class DrawableObject
{
public:
    DrawableObject(Model* model, ShaderProgram* shaderProgram);

    Transformation& getTransformation();

    void setColor(const glm::vec3& color);
    void setShaderProgram(ShaderProgram* shaderProgram);
    const glm::vec3& getColor() const;
    void draw();

private:
    Model* model;
    Transformation transformation;
    ShaderProgram* shaderProgram;
    glm::vec3 color; 
};

#endif // DRAWABLEOBJECT_H
