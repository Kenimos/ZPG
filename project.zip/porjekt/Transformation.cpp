// Transformation.cpp

#include "Transformation.h"

Transformation::Transformation()
    : position(0.0f), rotation(glm::quat()), scale(1.0f)
{
}

void Transformation::setPosition(const glm::vec3 &pos)
{
    position = pos;
}

void Transformation::setRotation(float angle, const glm::vec3 &axis)
{
    rotation = glm::angleAxis(angle, glm::normalize(axis));
}

void Transformation::setScale(const glm::vec3 &scl)
{
    scale = scl;
}

glm::vec3 Transformation::getPosition() const
{
    return position;
}

glm::quat Transformation::getRotation() const
{
    return rotation;
}

glm::vec3 Transformation::getScale() const
{
    return scale;
}

glm::mat4 Transformation::getModelMatrix() const
{
    glm::mat4 model = glm::translate(glm::mat4(1.0f), position);
    model *= glm::mat4_cast(rotation);
    model = glm::scale(model, scale);
    return model;
}
