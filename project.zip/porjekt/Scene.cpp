
//Scene.cpp
#include "Scene.h"
#include "../Models/tree.h"
#include "../Models/bushes.h"
#include "../Models/sphere.h"
#include "../Models/gift.h"
#include <random>
#include <glm/glm.hpp>
#include <iostream>
#include "ShaderLoader.h"

Scene::Scene(Camera *camera)
    : camera(camera), treeModel(nullptr), bushModel(nullptr), sphereModel(nullptr), giftModel(nullptr),
      light(nullptr), constantShader(nullptr), lambertShader(nullptr), phongShader(nullptr), blinnPhongShader(nullptr),
      currentShaderIndex(0)

{
}

Scene::~Scene()
{

    delete treeModel;
    delete bushModel;
    delete sphereModel;
    delete giftModel;

    delete constantShader;
    delete lambertShader;
    delete phongShader;
    delete blinnPhongShader;

    delete light;
}

void Scene::initShaders()
{

    ShaderLoader shaderLoader;

    constantShader = new ShaderProgram();
    GLuint constantProgramID = shaderLoader.loadShader("Shaders/constant_vertex.glsl", "Shaders/constant_fragment.glsl");
    constantShader->setProgramID(constantProgramID);

    lambertShader = new ShaderProgram();
    GLuint lambertProgramID = shaderLoader.loadShader("Shaders/lambert_vertex.glsl", "Shaders/lambert_fragment.glsl");
    lambertShader->setProgramID(lambertProgramID);

    phongShader = new ShaderProgram();
    GLuint phongProgramID = shaderLoader.loadShader("Shaders/phong_vertex.glsl", "Shaders/phong_fragment.glsl");
    phongShader->setProgramID(phongProgramID);

    blinnPhongShader = new ShaderProgram();
    GLuint blinnProgramID = shaderLoader.loadShader("Shaders/blinn_vertex.glsl", "Shaders/blinn_fragment.glsl");
    blinnPhongShader->setProgramID(blinnProgramID);

    shaders.push_back(constantShader);
    shaders.push_back(lambertShader);
    shaders.push_back(phongShader);
    shaders.push_back(blinnPhongShader);

    light = new Light(glm::vec3(0.0f, 5.0f, 5.0f),
                      glm::vec3(1.0f, 1.0f, 1.0f),
                      1.0f);

    light->attach(lambertShader);
    light->attach(phongShader);
    light->attach(blinnPhongShader);

    for (auto *shader : shaders)
    {
        light->attach(shader);
    }

    for (auto *shader : shaders)
    {
        camera->attach(shader);
    }

    light->notifyObservers();
    camera->notifyObservers();
}

void Scene::switchShaders()
{
    currentShaderIndex = (currentShaderIndex + 1) % shaders.size();

    ShaderProgram *newShader = shaders[currentShaderIndex];

    for (auto &object : drawableObjects)
    {
        object.setShaderProgram(newShader);
    }
}

void Scene::initScene1()
{
    if (!constantShader || !lambertShader || !phongShader || !blinnPhongShader)
    {
        initShaders();
    }

    loadModelsScene1();
}

void Scene::initScene2()
{
    if (!constantShader || !lambertShader || !phongShader || !blinnPhongShader)
    {
        initShaders();
    }

    loadModelsScene2();
}

void Scene::initScene3()
{
    if (!constantShader || !lambertShader || !phongShader || !blinnPhongShader)
    {
        initShaders();
    }

    loadModelsScene3();
}

void Scene::initScene4()
{
    if (!constantShader || !lambertShader || !phongShader || !blinnPhongShader)
    {
        initShaders();
    }

    loadModelsScene4();
}

void Scene::loadModelsScene1()
{

    std::vector<float> treeData(tree, tree + sizeof(tree) / sizeof(float));
    treeModel = new Model();
    treeModel->loadFromData(treeData);

    std::vector<float> bushData(bushes, bushes + sizeof(bushes) / sizeof(float));
    bushModel = new Model();
    bushModel->loadFromData(bushData);

    std::random_device rd;
    std::mt19937 gen(rd());

    std::uniform_real_distribution<float> positionDist(-50.0f, 50.0f);
    std::uniform_real_distribution<float> scaleDist(0.5f, 2.0f);
    std::uniform_real_distribution<float> rotationDist(0.0f, 360.0f);

    for (int i = 0; i < 50; ++i)
    {
        DrawableObject treeObject(treeModel, phongShader);

        float posX = positionDist(gen);
        float posZ = positionDist(gen);
        treeObject.getTransformation().setPosition(glm::vec3(posX, 0.0f, posZ));

        float rotationAngle = rotationDist(gen);
        treeObject.getTransformation().setRotation(glm::radians(rotationAngle), glm::vec3(0.0f, 1.0f, 0.0f));

        float scaleValue = scaleDist(gen);
        treeObject.getTransformation().setScale(glm::vec3(scaleValue));
        treeObject.setColor(glm::vec3(0.0f, 0.6f, 0.0f));
        drawableObjects.push_back(treeObject);
    }

    for (int i = 0; i < 50; ++i)
    {
        DrawableObject bushObject(bushModel, phongShader);

        float posX = positionDist(gen);
        float posZ = positionDist(gen);
        bushObject.getTransformation().setPosition(glm::vec3(posX, 0.0f, posZ));

        float rotationAngle = rotationDist(gen);
        bushObject.getTransformation().setRotation(glm::radians(rotationAngle), glm::vec3(0.0f, 1.0f, 0.0f));

        float scaleValue = scaleDist(gen);
        bushObject.getTransformation().setScale(glm::vec3(scaleValue));
        bushObject.setColor(glm::vec3(0.0f, 0.4f, 0.0f));
        drawableObjects.push_back(bushObject);
    }

    light->setPosition(glm::vec3(0.0f, 50.0f, 0.0f));
    light->setIntensity(1.0f);
    light->notifyObservers();
}

void Scene::loadModelsScene2()
{

    std::vector<float> sphereData(sphere, sphere + sizeof(sphere) / sizeof(float));
    sphereModel = new Model();
    sphereModel->loadFromData(sphereData);

    DrawableObject phongSphere(sphereModel, phongShader);
    phongSphere.getTransformation().setPosition(glm::vec3(-2.0f, 0.0f, -2.0f));
    phongSphere.setColor(glm::vec3(1.0f, 0.0f, 0.0f));
    drawableObjects.push_back(phongSphere);

    DrawableObject blinnSphere(sphereModel, blinnPhongShader);
    blinnSphere.getTransformation().setPosition(glm::vec3(2.0f, 0.0f, -2.0f));
    blinnSphere.setColor(glm::vec3(0.0f, 1.0f, 0.0f));
    drawableObjects.push_back(blinnSphere);

    DrawableObject lambertSphere(sphereModel, lambertShader);
    lambertSphere.getTransformation().setPosition(glm::vec3(-2.0f, 0.0f, 2.0f));
    lambertSphere.getTransformation().setScale(glm::vec3(1.5f));
    lambertSphere.setColor(glm::vec3(0.0f, 0.0f, 1.0f));
    drawableObjects.push_back(lambertSphere);

    DrawableObject constantSphere(sphereModel, constantShader);
    constantSphere.getTransformation().setPosition(glm::vec3(2.0f, 0.0f, 2.0f));
    constantSphere.setColor(glm::vec3(1.0f, 1.0f, 0.0f));
    drawableObjects.push_back(constantSphere);

    light->setPosition(glm::vec3(0.0f, 0.5f, 0.0f));
    light->setIntensity(1.0f);
    light->notifyObservers();
}

void Scene::loadModelsScene3()
{

    std::vector<float> triangleData = {
        -0.5f,
        -0.5f,
        0.0f,
        0.0f,
        0.0f,
        1.0f,
        0.5f,
        -0.5f,
        0.0f,
        0.0f,
        0.0f,
        1.0f,
        0.0f,
        0.5f,
        0.0f,
        0.0f,
        0.0f,
        1.0f,
    };

    Model *triangleModel = new Model();
    triangleModel->loadFromData(triangleData);

    DrawableObject triangleObject(triangleModel, phongShader);
    triangleObject.getTransformation().setPosition(glm::vec3(0.0f, 0.0f, -2.0f));
    triangleObject.setColor(glm::vec3(1.0f, 0.5f, 0.31f));
    drawableObjects.push_back(triangleObject);

    light->setPosition(glm::vec3(0.0f, 3.0f, 0.0f));
    light->setIntensity(1.0f);
    light->notifyObservers();
}

void Scene::loadModelsScene4()
{

    std::vector<float> giftData(gift, gift + sizeof(gift) / sizeof(float));
    giftModel = new Model();
    giftModel->loadFromData(giftData);

    std::vector<float> sphereData(sphere, sphere + sizeof(sphere) / sizeof(float));
    sphereModel = new Model();
    sphereModel->loadFromData(sphereData);

    std::random_device rd;
    std::mt19937 gen(rd());

    std::uniform_real_distribution<float> positionDist(-50.0f, 50.0f);
    std::uniform_real_distribution<float> scaleDist(1.0f, 3.0f);
    std::uniform_real_distribution<float> rotationDist(0.0f, 360.0f);

    for (int i = 0; i < 50; ++i)
    {
        DrawableObject giftObject(giftModel, phongShader);

        float posX = positionDist(gen);
        float posY = positionDist(gen);
        float posZ = positionDist(gen);
        giftObject.getTransformation().setPosition(glm::vec3(posX, posY, posZ));

        float rotationAngle = rotationDist(gen);
        giftObject.getTransformation().setRotation(glm::radians(rotationAngle), glm::vec3(0.0f, 1.0f, 0.0f));

        float scaleValue = scaleDist(gen);
        giftObject.getTransformation().setScale(glm::vec3(scaleValue));
        giftObject.setColor(glm::vec3(0.5f, 0.0f, 0.0f));
        drawableObjects.push_back(giftObject);
    }

    for (int i = 0; i < 200; ++i)
    {
        DrawableObject sphereObject(sphereModel, phongShader);

        float posX = positionDist(gen);
        float posY = positionDist(gen);
        float posZ = positionDist(gen);
        sphereObject.getTransformation().setPosition(glm::vec3(posX, posY, posZ));

        float rotationAngle = rotationDist(gen);
        sphereObject.getTransformation().setRotation(glm::radians(rotationAngle), glm::vec3(0.0f, 1.0f, 0.0f));

        float scaleValue = scaleDist(gen);
        sphereObject.getTransformation().setScale(glm::vec3(scaleValue));
        sphereObject.setColor(glm::vec3(0.0f, 0.0f, 0.5f));
        drawableObjects.push_back(sphereObject);
    }

    light->setPosition(glm::vec3(0.0f, 25.0f, 0.0f));
    light->setIntensity(5.0f);
    light->notifyObservers();
}

void Scene::draw()
{
    if (light)
    {
        light->notifyObservers();
    }

    for (auto &object : drawableObjects)
    {
        object.draw();
    }
}

Light *Scene::getLight()
{
    return light;
}

ShaderProgram *Scene::getPhongShader()
{
    return phongShader;
}

ShaderProgram *Scene::getLambertShader()
{
    return lambertShader;
}

ShaderProgram *Scene::getBlinnPhongShader()
{
    return blinnPhongShader;
}

ShaderProgram *Scene::getConstantShader()
{
    return constantShader;
}