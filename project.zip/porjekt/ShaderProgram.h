#ifndef SHADERPROGRAM_H
#define SHADERPROGRAM_H

#include <GL/glew.h>
#include <string>
#include <glm/glm.hpp>
#include "Shader.h"
#include "Observer.h"
#include "Light.h"
#include "Camera.h"

class ShaderProgram : public Observer
{
public:
    ShaderProgram();
    virtual ~ShaderProgram();

    void use();

    // Uniform setters
    void setMat4(const std::string &name, const glm::mat4 &mat);
    void setVec3(const std::string &name, const glm::vec3 &vec);
    void setFloat(const std::string &name, float value);

    // Observer method
    void update(Subject *subject) override;
    void setProgramID(GLuint programID);
    void retrieveUniformLocations();

private:
    GLuint programID;
    glm::mat4 viewMatrix;
    glm::mat4 projectionMatrix;

    glm::vec3 cameraPosition;
    glm::vec3 lightPosition;
    glm::vec3 lightColor;
    float lightIntensity;
    std::unordered_map<std::string, GLint> uniformLocations;
};

#endif // SHADERPROGRAM_H
